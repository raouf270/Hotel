﻿namespace Hotel.Data.Entities
{
    public class Room
    {
        public Room()
        {
            RoomId = Guid.NewGuid();
            RoomType = string.Empty;
            RoomNumber = string.Empty;
            PricePerNight = string.Empty;
            IsAvailable = string.Empty;
        }
        public Room(Guid roomId, string roomType, string roomNumber, string pricePerNight, string isAvailable)
        {
            RoomId = roomId;
            RoomType = roomType;
            RoomNumber = roomNumber;
            PricePerNight = pricePerNight;
            IsAvailable = isAvailable;
        }
        public Guid RoomId { get; set; }
        public string RoomType { get; set; }
        public string RoomNumber { get; set; }
        public string PricePerNight { get; set; }
        public string IsAvailable { get; set; }
        public List<Booking> Bookings { get; set; } = [];
    }
}
