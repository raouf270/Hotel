﻿namespace Hotel.Data.Entities
{
    public class Booking
    {
        public Guid BookingId { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public Room Room { get; set; }
        public Guid RoomId { get; set; }
    }
}
