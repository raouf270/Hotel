﻿using Hotel.Components.Pages.RoomComponents;
using Microsoft.EntityFrameworkCore;
using Hotel.Data;
using Hotel.Data.Entities;

namespace Hotel.Components.Pages.RoomComponents
{
    public class RoomServes : IRoomServes
    {
        private readonly IDbContextFactory<ApplicationDbContext> _dbContextFactory;

        public RoomServes(IDbContextFactory<ApplicationDbContext> dbContextFactory)
        {
            _dbContextFactory = dbContextFactory;
        }

        public async Task DeleteRoomAsync(Guid RoomId)
        {
            var _dbContext = _dbContextFactory.CreateDbContext();
            var Room = await _dbContext.Rooms.FindAsync(RoomId);
            if (Room != null)
            {
                _dbContext.Rooms.Remove(Room);
                await _dbContext.SaveChangesAsync();
            }
          
        }

        public async Task<RoomDto> GetRoomAsync(Guid RoomId)
        {
            var _dbContext = _dbContextFactory.CreateDbContext();
            var Room = await _dbContext.Rooms.FindAsync(RoomId);
            if (Room == null)
                return null;

            return new RoomDto
            {
                RoomId = Room.RoomId,
                RoomType = Room.RoomType,
                RoomNumber = Room.RoomNumber,
                PricePerNight = Room.PricePerNight,
                IsAvailable = Room.IsAvailable,
            };
        }

        public async Task<IEnumerable<RoomDto>> GetRoomAsync(string RoomNumber)
        {
            var _dbContext = _dbContextFactory.CreateDbContext();
            var Rooms = await _dbContext.Rooms
         .Where(f => f.RoomNumber.Contains(RoomNumber))
         .Select(f => new RoomDto
         {
             RoomId = f.RoomId,
             RoomType = f.RoomType,
             RoomNumber = f.RoomNumber,
             PricePerNight = f.PricePerNight,
             IsAvailable = f.IsAvailable,

         }).ToListAsync();

            return Rooms;
        }

        public async Task<IEnumerable<RoomDto>> GetRoomsAsync()
        {
            var _dbContext = _dbContextFactory.CreateDbContext();
            var Rooms = await _dbContext.Rooms
         .Select(f => new RoomDto
         {
             RoomId = f.RoomId,
             RoomType = f.RoomType,
             RoomNumber = f.RoomNumber,
             PricePerNight = f.PricePerNight,
             IsAvailable = f.IsAvailable,
         })
         .ToListAsync();

            return Rooms;
        }

        public async Task<RoomDto> UpsertRoomAsync(RoomDto Room)
        {
            var _dbContext = _dbContextFactory.CreateDbContext();
            var room = new Room
            {
                RoomId = Room.RoomId,
                RoomType = Room.RoomType,
                RoomNumber = Room.RoomNumber,
                 PricePerNight = Room.PricePerNight,
                IsAvailable = Room.IsAvailable,
            };

            var existingroom = await _dbContext.Rooms
                .FirstOrDefaultAsync(f => f.RoomNumber == Room.RoomNumber);

            if (existingroom == null)
            {
                await _dbContext.Rooms.AddAsync(room);
                await _dbContext.SaveChangesAsync();
            }
            else
            {

                existingroom.RoomType = room.RoomType;
                existingroom.RoomNumber = room.RoomNumber;
                existingroom.PricePerNight = room.PricePerNight;
                existingroom.IsAvailable = room.IsAvailable;
                await _dbContext.SaveChangesAsync();
            }

            

            return new RoomDto
            {
                RoomId = room.RoomId,
                RoomType = room.RoomType,
                RoomNumber = room.RoomNumber,
                PricePerNight = room.PricePerNight,
                IsAvailable = room.IsAvailable,
            };
        }
    }
}
