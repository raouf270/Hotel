﻿namespace Hotel.Components.Pages.RoomComponents
   
{
    public class RoomDto
    {
        public Guid RoomId { get; set; }
        public string RoomType { get; set; }
        public string RoomNumber { get; set; }
        public string PricePerNight { get; set; }
        public string IsAvailable { get; set; }
        public int BookingsCount { get; set; }
    }
}
