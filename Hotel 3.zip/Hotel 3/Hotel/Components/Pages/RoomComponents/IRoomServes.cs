﻿using Hotel.Components.Pages.RoomComponents;

namespace Hotel.Components.Pages.RoomComponents
{
    public interface IRoomServes
    {
        Task<IEnumerable<RoomDto>> GetRoomsAsync();
        Task<RoomDto> GetRoomAsync(Guid RoomId);
        Task<IEnumerable<RoomDto>> GetRoomAsync(string RoomNumber);
        Task<RoomDto> UpsertRoomAsync(RoomDto Room);
        Task DeleteRoomAsync(Guid RoomId);
    }
}
