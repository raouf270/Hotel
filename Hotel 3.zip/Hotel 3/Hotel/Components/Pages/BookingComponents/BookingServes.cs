﻿
using Hotel.Data;
using Hotel.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Hotel.Components.Pages.BookingComponents
{
    public class BookingServes : IBookingServes
    {
        private readonly IDbContextFactory<ApplicationDbContext> _dbContextFactory;
        public BookingServes(IDbContextFactory<ApplicationDbContext> dbContextFactory)
        {
            _dbContextFactory = dbContextFactory;
        }
        public async Task DeleteBookingAsync(Guid BookingId)
        {
            var _context = _dbContextFactory.CreateDbContext();
            var booking = await _context.Bookings.FindAsync(BookingId);
            if (booking != null)
            {
                _context.Bookings.Remove(booking);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<BookingDto>> GetAllBookingAsync()
        {
            var _context = _dbContextFactory.CreateDbContext();
            return await _context.Bookings
                .Select(p => new BookingDto
                {
                    BookingId = p.BookingId,
                    CheckInDate = p.CheckInDate,
                    CheckOutDate = p.CheckOutDate,
                    RoomId = p.RoomId
                })
                .ToListAsync();
        }

        public async Task<BookingDto?> GetBookingByIdAsync(Guid BookingId)
        {
            var _context = _dbContextFactory.CreateDbContext();
            var booking = await _context.Bookings.FindAsync(BookingId);
            if (booking == null) return null;

            return new BookingDto
            {
                BookingId = booking.BookingId,
                CheckInDate = booking.CheckInDate,
                CheckOutDate = booking.CheckOutDate,
                RoomId = booking.RoomId
            };
        }

        public async Task<IEnumerable<BookingDto>> GetRoomBookingsAsync(Guid RoomId)
        {
            var _context = _dbContextFactory.CreateDbContext();
            var bookings = await _context.Bookings
                .Where(p => p.RoomId == RoomId)
                .Select(p => new BookingDto
                {
                    BookingId = p.BookingId,
                    CheckInDate = p.CheckInDate,
                    CheckOutDate = p.CheckOutDate,
                    RoomId = p.RoomId
                }).ToListAsync();

            return bookings;
        }

        public async Task<BookingDto> UpsertBookingAsync(BookingDto Booking)
        {
            var _context = _dbContextFactory.CreateDbContext();
            var entity = new Booking
            {
                BookingId = Booking.BookingId,
                CheckInDate = (DateTime)Booking.CheckInDate,
                CheckOutDate = (DateTime)Booking.CheckOutDate,
                RoomId = Booking.RoomId
            };

            var existing = await _context.Bookings.FindAsync(entity.BookingId);
            if (existing == null)
            {
                _context.Bookings.Add(entity);
            }
            else
            {
               
                existing.CheckInDate = entity.CheckInDate;
                existing.CheckOutDate = entity.CheckOutDate;
                existing.RoomId = entity.RoomId;
            }

            await _context.SaveChangesAsync();

            return new BookingDto
            {
                BookingId = entity.BookingId,
                CheckInDate = entity.CheckInDate,
                CheckOutDate = entity.CheckOutDate,
                RoomId = entity.RoomId
            };
        }
    }
}
