﻿namespace Hotel.Components.Pages.BookingComponents
{
    public class BookingDto
    {
        public Guid BookingId { get; set; }
        public DateTime? CheckInDate { get; set; }
        public DateTime? CheckOutDate { get; set; }
        public Guid RoomId { get; set; }

    }
}
