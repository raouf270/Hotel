﻿namespace Hotel.Components.Pages.BookingComponents
{

    public interface IBookingServes
    {


        Task<IEnumerable<BookingDto>> GetAllBookingAsync();
        Task<IEnumerable<BookingDto>> GetRoomBookingsAsync(Guid RoomId);
        Task<BookingDto?> GetBookingByIdAsync(Guid id);
        Task<BookingDto> UpsertBookingAsync(BookingDto Booking);
        Task DeleteBookingAsync(Guid id);

    }
}
