﻿using Microsoft.EntityFrameworkCore;
using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using Hotel.Components.Pages.BookingComponents;

using Moq;
using Hotel.Data;
using Hotel.Data.Entities;
using Hotel.Components.Pages.BookingComponents;

namespace Hotel.Test
{
    public class BookingServesTests
    {
        private IDbContextFactory<ApplicationDbContext> GetDbContextFactory(DbContextOptions<ApplicationDbContext> options)
        {
            var mockFactory = new Mock<IDbContextFactory<ApplicationDbContext>>();
            mockFactory.Setup(f => f.CreateDbContext()).Returns(new ApplicationDbContext(options));
            return mockFactory.Object;
        }

        private static DbContextOptions<ApplicationDbContext> GetNewContextOptions()
        {
            return new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;
        }

        [Fact]
        public async Task GetAllBookingsAsync_ShouldReturnAllBookings()
        {
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            // Arrange
            var bookings = new List<Booking>
            {
                new Booking
                {
                    BookingId = Guid.NewGuid(),
                    CheckInDate = DateTime.Now,
                    CheckOutDate = DateTime.Now,
                    RoomId = Guid.NewGuid()
                },
                new Booking
                {
                    BookingId = Guid.NewGuid(),
                    CheckInDate = DateTime.Now,
                    CheckOutDate = DateTime.Now,
                    RoomId = Guid.NewGuid()
                }
            };

            var context = factory.CreateDbContext();

            context.Bookings.AddRange(bookings);
            await context.SaveChangesAsync();


            var service = new BookingServes(factory);

            // Act
            var result = await service.GetAllBookingAsync();

            // Assert
            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task GetBookingByIdAsync_ShouldReturnBooking_WhenBookingExists()
        {
            // Arrange
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            var bookingId = Guid.NewGuid();
            var booking = new Booking
            {
                BookingId = bookingId,
                CheckInDate = DateTime.Now,
                CheckOutDate = DateTime.Now,
                RoomId = Guid.NewGuid()
            };

            var context = factory.CreateDbContext();
            context.Bookings.Add(booking);
            await context.SaveChangesAsync();


            var service = new BookingServes(factory);

            // Act
            var result = await service.GetBookingByIdAsync(bookingId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(booking.BookingId, result.BookingId);
        }

        [Fact]
        public async Task GetBookingByIdAsync_ShouldReturnNull_WhenBookingDoesNotExist()
        {
            // Arrange
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            var bookingId = Guid.NewGuid();
            var service = new BookingServes(factory);

            // Act
            var result = await service.GetBookingByIdAsync(bookingId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task DeleteBookingAsync_ShouldRemoveBooking_WhenBookingExists()
        {
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            // Arrange
            var bookingId = Guid.NewGuid();
            var booking = new Booking
            {
                BookingId = bookingId,
                CheckInDate = DateTime.Now,
                CheckOutDate = DateTime.Now,
                RoomId = Guid.NewGuid()
            };

            var cf = factory.CreateDbContext();
            cf.Bookings.Add(booking);
            await cf.SaveChangesAsync();


            var service = new BookingServes(factory);

            // Act
            await service.DeleteBookingAsync(bookingId);

            // Assert
            using var context = factory.CreateDbContext();
            var deletedBooking = await context.Bookings.FindAsync(bookingId);
            Assert.Null(deletedBooking);
        }

        [Fact]
        public async Task GetRoomBookingsAsync_ShouldReturnBookings_WhenBookingsExist()
        {
            // Arrange
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            var roomId = Guid.NewGuid();
            var bookings = new List<Booking>
            {
                new Booking
                {
                BookingId = Guid.NewGuid(),
                CheckInDate = DateTime.Now,
                CheckOutDate = DateTime.Now,
                RoomId = roomId
                },
                new Booking
                {
                    BookingId = Guid.NewGuid(),
                CheckInDate = DateTime.Now,
                CheckOutDate = DateTime.Now,
                RoomId = roomId
                }
            };

            var context = factory.CreateDbContext();

            context.Bookings.AddRange(bookings);
            await context.SaveChangesAsync();


            var service = new BookingServes(factory);

            // Act
            var result = await service.GetRoomBookingsAsync(roomId);

            // Assert
            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task UpsertBookingAsync_ShouldAddNewBooking_WhenBookingDoesNotExist()
        {
            // Arrange
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            var bookingDto = new BookingDto
            {
                BookingId = Guid.NewGuid(),
                CheckInDate = DateTime.Now,
                CheckOutDate = DateTime.Now,
                RoomId = Guid.NewGuid()
            };

            var service = new BookingServes(factory);

            // Act
            var result = await service.UpsertBookingAsync(bookingDto);

            // Assert
            var context = factory.CreateDbContext();
            var addedBooking = await context.Bookings.FindAsync(result.BookingId);
            Assert.NotNull(addedBooking);
            Assert.Equal(bookingDto.RoomId, addedBooking.RoomId);
        }

        
      
    }
}
