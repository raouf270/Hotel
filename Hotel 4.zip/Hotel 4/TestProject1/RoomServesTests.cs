﻿using Microsoft.EntityFrameworkCore;
using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using Hotel.Components.Pages.RoomComponents;

using Moq;
using Hotel.Data;
using Hotel.Data.Entities;

namespace Hotel.Test
{
    public class RoomServesTests
    {
        private IDbContextFactory<ApplicationDbContext> GetDbContextFactory(DbContextOptions<ApplicationDbContext> options)
        {
            var mockFactory = new Mock<IDbContextFactory<ApplicationDbContext>>();
            mockFactory.Setup(f => f.CreateDbContext()).Returns(new ApplicationDbContext(options));
            return mockFactory.Object;
        }

        private static DbContextOptions<ApplicationDbContext> GetNewContextOptions()
        {
            return new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;
        }

        [Fact]
        public async Task UpsertRoomAsync_ShouldAddNewRoom_WhenRoomDoesNotExist()
        {
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);

            // Arrange
            var roomDto = new RoomDto
            {
                RoomId = Guid.NewGuid(),
                RoomType = "Double",
                RoomNumber = "10",
                PricePerNight = "80",
                IsAvailable = "Available",
            };

            var service = new RoomServes(factory);

            // Act
            var result = await service.UpsertRoomAsync(roomDto);

            // Assert
            using var context = new ApplicationDbContext(options);
            var addedMember = await context.Rooms.FindAsync(result.RoomId);
            Assert.NotNull(addedMember);
            Assert.Equal(roomDto.RoomNumber, addedMember.RoomNumber);
        }

        //[Fact]
        //public async Task UpsertRoomAsync_ShouldUpdateExistingRoom_WhenRoomExists()
        //{
        //    // Arrange
        //    var options = GetNewContextOptions();
        //    var factory = GetDbContextFactory(options);
        //    var service = new RoomServes(factory);

        //    var existingRoom = new Room
        //    {
        //        RoomId = Guid.NewGuid(),
        //        RoomType = "Double",
        //        RoomNumber = "10",
        //        PricePerNight = "80",
        //        IsAvailable = "Available",
        //    };

        //    var cf = factory.CreateDbContext();
        //    cf.Rooms.Add(existingRoom);
        //    await cf.SaveChangesAsync();



        //    var roomDto = new RoomDto
        //    {
        //        RoomId = existingRoom.RoomId,
        //        RoomType = "single",
        //        RoomNumber = "11",
        //        PricePerNight = "75",
        //        IsAvailable = "notAvailable",
        //    };

        //    // Act

        //    var result = await service.UpsertRoomAsync(roomDto);

        //    // Assert11

        //        var context = factory.CreateDbContext();
        //        var updatedMember = await context.Rooms.FindAsync(result.RoomId);
        //        Assert.NotNull(updatedMember);
        //        Assert.Equal(roomDto.RoomNumber, updatedMember.RoomNumber);
        //        Assert.Equal(roomDto.IsAvailable, updatedMember.IsAvailable);
        //}

        [Fact]
        public async Task DeleteRoomAsync_ShouldRemoveRoom_WhenRoomExists()
        {

            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            // Arrange
            var roomId = Guid.NewGuid();
            var existingRoom = new Room
            {
                RoomId = roomId,
                RoomType = "Double",
                RoomNumber = "11",
                PricePerNight = "100",
                IsAvailable = "Available",
            };

            using (var cf = factory.CreateDbContext())
            {
                cf.Rooms.Add(existingRoom);
                await cf.SaveChangesAsync();
            }
            options = GetNewContextOptions();
            factory = GetDbContextFactory(options);
            var service = new RoomServes(factory);

            // Act
            await service.DeleteRoomAsync(roomId);

            // Assert
            options = GetNewContextOptions();
            factory = GetDbContextFactory(options);
            using var context = factory.CreateDbContext();
            var deletedMember = await context.Rooms.FindAsync(roomId);
            Assert.Null(deletedMember);
        }

        [Fact]
        public async Task GetRoomAsync_ShouldReturnRoom_WhenRoomExists()
        {
            // Arrange
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            var service = new RoomServes(factory);
            var newRoom = new RoomDto
            {
                RoomType = "Double",
                RoomNumber = "11",
                PricePerNight = "100",
                IsAvailable = "non Available"
            };
            var savedRoom = await service.UpsertRoomAsync(newRoom);

            // Act
            var fetchedRoom = await service.GetRoomAsync(savedRoom.RoomId);

            // Assert
            Assert.NotNull(fetchedRoom);
            Assert.Equal(newRoom.RoomNumber, fetchedRoom.RoomNumber);
        }

        [Fact]
        public async Task GetRoomAsync_ShouldReturnNull_WhenRoomDoesNotExist()
        {
            // Arrange
            var options = GetNewContextOptions();
            var factory = GetDbContextFactory(options);
            var service = new RoomServes(factory);
            // Arrange
            var roomId = Guid.NewGuid();

            // Act
            var result = await service.GetRoomAsync(roomId);

            // Assert
            Assert.Null(result);
        }
    }
}
